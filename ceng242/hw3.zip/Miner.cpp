#include "Miner.h"
#include <iostream>

int Miner::getNextAvailableBlockchainID() const {
    return blockchains.size();
}

Miner::Miner(std::string name) : name(name), blockchains() {}

Miner::Miner(const Miner& rhs) : name(rhs.name) {
    for (Blockchain* i : rhs.blockchains) {
        (this -> blockchains).push_back(new Blockchain(*i));
    }
}

Miner& Miner::operator=(const Miner& rhs) {
    if (this == &rhs)
        return *this;
    for (Blockchain* i : blockchains) {
        if (i -> getSoftForked() == true) {
            i -> setHead(nullptr);
        }
        delete i;
    }
    blockchains.clear();
    name.clear();
    for (Blockchain* i : rhs.blockchains) {
        blockchains.push_back(new Blockchain(*i));
    }
    name = rhs.name;
    return *this;
}

Miner::~Miner() {
    for (Blockchain* i : blockchains) {
        if (i -> getSoftForked() == true) {
            i -> setHead(nullptr);
        }
        delete i;
    }
    blockchains.clear();
    name.clear();
}

void Miner::createNewBlockchain() {
    blockchains.push_back(new Blockchain(getNextAvailableBlockchainID()));
}

void Miner::mineUntil(int cycleCount) {
    for (int j = 0; j < cycleCount; j++) {
        for (Blockchain* i : blockchains) {
            ++(*i);
        }
    }
}

void Miner::demineUntil(int cycleCount) {
    for (int j = 0; j < cycleCount; j++) {
        for (Blockchain* i : blockchains) {
            --(*i);
        }
    }
}

std::string Miner::getName() const {
    return name;
}

double Miner::getTotalValue() const {
    double total_value = 0;
    for (Blockchain* i : blockchains) {
        if (i -> getSoftForked() == false) {
            total_value += (*i).getTotalValue();
        }
    }
    return total_value;
}

long Miner::getBlockchainCount() const {
    return (long) blockchains.size();
}

Blockchain* Miner::operator[](int id) const {
    if (id < blockchains.size())
        return blockchains[id];
    return nullptr;
}

bool Miner::softFork(int blockchainID) {
    if (blockchainID >= blockchains.size())
        return false;
    Blockchain* old_blockchain = blockchains[blockchainID];
    int id = getNextAvailableBlockchainID();
    if (old_blockchain -> getHead() == nullptr)
    {
        blockchains.push_back(new Blockchain(id, nullptr, false));
        return true;
    }
    Koin* p = old_blockchain -> getHead();
    while (p -> getNext() != nullptr) {
        p = p -> getNext();
    }
    p -> setSoftForked(true);
    blockchains.push_back(new Blockchain(id, p, true));
    return true;
}

bool Miner::hardFork(int blockchainID) {
    if (blockchainID >= blockchains.size())
        return false;
    Blockchain* old_blockchain = blockchains[blockchainID];
    int id = getNextAvailableBlockchainID();
    if (old_blockchain -> getHead() == nullptr)
    {
        blockchains.push_back(new Blockchain(id));
        return true;
    }
    Koin* p = old_blockchain -> getHead();
    while (p -> getNext() != nullptr) {
        p = p -> getNext();
    }
    blockchains.push_back(new Blockchain(id, new Koin(p -> getValue())));
    return true;
}

std::ostream& operator<<(std::ostream& os, const Miner& miner) {
    os.precision(Utilizer::koinPrintPrecision());
    os << std::fixed;
    os << "-- BEGIN MINER --" << std::endl
       << "Miner name: " << miner.getName() << std::endl
       << "Blockchain count: " << miner.getBlockchainCount() << std::endl
       << "Total value: " << miner.getTotalValue() << std::endl << std:: endl;
    for (Blockchain* i : miner.blockchains) {
        os << (*i) << std::endl;
    }
    os << std::endl << "-- END MINER --" << std::endl;
}
