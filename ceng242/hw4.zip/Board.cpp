#include "Board.h"

/*
YOU MUST WRITE THE IMPLEMENTATIONS OF THE REQUESTED FUNCTIONS
IN THIS FILE. START YOUR IMPLEMENTATIONS BELOW THIS LINE 
*/

Board::Board(uint boardSize, std::vector<Player *> *players) : boardSize(boardSize),
															   players(players),
															   hill((boardSize - 1)/2, (boardSize - 1)/2),
															   stormWidth(0),
															   stormDamage(0) {}

Board::~Board() {}

uint Board::getSize() const {
	return boardSize;
}

bool Board::isCoordInBoard(const Coordinate& coord) const {
	if (coord.x >= 0 && coord.x < boardSize &&
		coord.y >= 0 && coord.y < boardSize)
		return true;
	return false;
}

bool Board::isStormInCoord(const Coordinate &coord) const {
	if (stormWidth == 0 || isCoordHill(coord) || !isCoordInBoard(coord))
		return false;
	int first_bound = stormWidth;
	int second_bound = boardSize - 1 - stormWidth;
	if (coord.x < first_bound || coord.x > second_bound ||
		coord.y < first_bound || coord.y > second_bound)
		return true;
	return false;
}

bool Board::isCoordHill(const Coordinate& coord) const {
	return ((coord == hill) ? (true) : (false));
}

Player* Board::operator[](const Coordinate& coord) const {
	if (!isCoordInBoard(coord))
		return nullptr;
	for (Player* player: *players) {
		if (player -> getCoord() == coord)
			return player;
	}
	return nullptr;
}

Coordinate Board::calculateCoordWithMove(Move move, const Coordinate &coord) const {
	if (move == NOOP || move == ATTACK)
		return coord;
	Coordinate new_coord = coord + move;
	if (isCoordInBoard(new_coord))
		return new_coord;
	return coord;
}

std::vector<Coordinate> Board::visibleCoordsFromCoord(const Coordinate &coord) const {
	std::vector<Coordinate> visible_coords;
	if (!isCoordInBoard(coord))
		return visible_coords;
	Coordinate up = coord + UP;
	Coordinate down = coord + DOWN;
	Coordinate left = coord + LEFT;
	Coordinate right = coord + RIGHT;
	if (isCoordInBoard(up))
		visible_coords.push_back(up);
	if (isCoordInBoard(down))
		visible_coords.push_back(down);
	if (isCoordInBoard(left))
		visible_coords.push_back(left);
	if (isCoordInBoard(right))
		visible_coords.push_back(right);
	return visible_coords;
}

void Board::updateStorm(uint currentRound) {
	stormWidth = Entity::stormWidthForRound(currentRound);
	stormDamage = Entity::stormDamageForRound(currentRound);
}

Coordinate Board::getHill() const {
	return hill;
}

uint Board::getStormWidth() const {
	return stormWidth;
}

int Board::getStormDamage() const {
	return stormDamage;
}
