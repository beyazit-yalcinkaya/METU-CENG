#include "GameEngine.h"

/*
YOU MUST WRITE THE IMPLEMENTATIONS OF THE REQUESTED FUNCTIONS
IN THIS FILE. START YOUR IMPLEMENTATIONS BELOW THIS LINE 
*/

GameEngine::GameEngine(uint boardSize, std::vector<Player *> *players) : currentRound(1),
															             board(boardSize, players),
															             players(players) {}

GameEngine::~GameEngine() {
	for (Player* player: *players)
		delete player;
	players -> clear();
	delete players;
}

const Board& GameEngine::getBoard() const {
	return board;
}

Player* GameEngine::operator[](uint id) const {
	for (Player* player: *players) {
		if (player -> getID() == id)
			return player;
	}
	return nullptr;
}

bool GameEngine::isFinished() const {
	if (players == nullptr || players -> size() == 0 ||
	   (players -> size() == 1 && board.isCoordHill((*players)[0] -> getCoord())))
	    return true;
	return false;
}

void GameEngine::takeTurn() {
	std::cout << "-- START ROUND " << currentRound << " --" << std::endl;
	board.updateStorm(currentRound);
	int i = 0;
	Player* player;
	while (i < players -> size()) {
		player = (*players)[i];
		takeTurnForPlayer(player -> getID());
		if (player == (*players)[i])
			i++;
	}
	std::cout << "-- END ROUND " << currentRound << " --" << std::endl;
	currentRound++;
}

Move GameEngine::takeTurnForPlayer(uint playerID) {
	Player* player = (*this)[playerID];
	if (player == nullptr)
		return NOOP;
	Coordinate coord = player -> getCoord();
	std::vector<Move> priorityList = player -> getPriorityList();
	std::vector<Coordinate> visibilityCoords = board.visibleCoordsFromCoord(coord);
	if (board.isStormInCoord(coord)) {
		std::cout << (player -> getFullName()) << "(" << (player -> getHP()) << ") is STORMED! (-" << board.getStormDamage() << ")" << std::endl;
		player -> damage(board.getStormDamage());
		if (player -> isDead()) {
			std::cout << (player -> getFullName()) << "(" << (player -> getHP()) << ") DIED." << std::endl;
			players -> erase(std::find(players -> begin(), players -> end(), player));
			delete player;
			return NOOP;
		}
	}
	for (Move move: priorityList) {
		if (move == NOOP) {
			return NOOP;
		}
		else if (move == ATTACK) {
			std::vector<Player*> nearPlayers;
			Player* near;
			for (Coordinate i: visibilityCoords) {
				near = board[i];
				if (near != nullptr) {
					nearPlayers.push_back(near);
				}
			}
			if (nearPlayers.empty())
				continue;
			else {
				std::sort(nearPlayers.begin(), nearPlayers.end(), [](Player* a, Player* b) {return (a -> getID()) < (b -> getID());});
			    near = nearPlayers[0];
			    bool isPlayerDead = player -> attackTo(near);
			    if (isPlayerDead) {
			    	std::cout << (near -> getFullName()) << "(" << (near -> getHP()) << ") DIED." << std::endl;
			    	players -> erase(std::find(players -> begin(), players -> end(), near));
					delete near;
			    }
			    return ATTACK;
			}
		}
		else {
			Coordinate new_coord = board.calculateCoordWithMove(move, coord);
			Coordinate hill = board.getHill();
			if (new_coord != coord && (new_coord - hill < coord - hill) && board[new_coord] == nullptr) {
				player -> executeMove(move);
				return move;
			}
			else
				continue;
		}
	}
	return NOOP;
}

Player* GameEngine::getWinnerPlayer() const {
	if (players == nullptr || players -> size() == 0 || players -> size() != 1 ||
	   (players -> size() == 1 && !(board.isCoordHill((*players)[0] -> getCoord()))))
		return nullptr;
	return (*players)[0];
}

