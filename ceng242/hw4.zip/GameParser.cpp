#include "GameParser.h"

/*
YOU MUST WRITE THE IMPLEMENTATIONS OF THE REQUESTED FUNCTIONS
IN THIS FILE. START YOUR IMPLEMENTATIONS BELOW THIS LINE 
*/


/**
* Parse the file with given name and create players accordingly.
*
* GameParser DOES NOT have any responsibility over these Players.
*
* Note: The file will always exists, and there will be no erroneous input.
*
* @param filename The name of the file to be parsed.
* @return  pair.first: Board size.
*          pair.second: The vector of the constructed players.
*/

std::pair<int, std::vector<Player *> *> GameParser::parseFileWithName(const std::string& filename) {
	std::ifstream file;
	file.open(filename);
	std::string buffer;
	std::string temp;
	std::string name;
	int counter = 0;
	int boardSize;
	int n;
	uint id;
	int x;
	int y;
	std::vector<Player *> * players = new std::vector<Player *>();
	file >> temp >> temp >> boardSize;
	file >> temp >> temp >> n;
	for (int i = 0; i < n; i++) {
		file >> temp;
		counter = 0;
		buffer.clear();
		for (int j = 0; j < temp.size(); j++) {
			if (temp[j] != ':') {
				buffer += temp[j];
			}
			else {
				switch (counter) {
					case 0: id = std::stoi(buffer); break;
					case 1: name = buffer; break;
					case 2: x = std::stoi(buffer); break;
					default: break;
				}
				buffer.clear();
				counter++;
				j++;
			}
		}
		y = std::stoi(buffer);
		if (name == "Berserk") {
			players -> push_back((new Berserk(id, x, y)));			
		}
		else if (name == "Tracer") {
			players -> push_back((new Tracer(id, x, y)));			
		}
		else if (name == "Ambusher") {
			players -> push_back((new Ambusher(id, x, y)));			
		}
		else if (name == "Pacifist") {
			players -> push_back((new Pacifist(id, x, y)));			
		}
		else if (name == "Dummy") {
			players -> push_back((new Dummy(id, x, y)));			
		}
		else {
			;
		}
	}
	file.close();
	std::sort(players -> begin(), players -> end(), [](Player* a, Player* b) {return (a -> getID()) < (b -> getID());});
	return std::make_pair(boardSize, players);
}
