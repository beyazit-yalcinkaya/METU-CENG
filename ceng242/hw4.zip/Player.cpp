#include "Player.h"

/*
YOU MUST WRITE THE IMPLEMENTATIONS OF THE REQUESTED FUNCTIONS
IN THIS FILE. START YOUR IMPLEMENTATIONS BELOW THIS LINE 
*/

Player::Player(uint id, int x, int y) : id(id), coordinate(x, y), HP(0) {}

Player::Player(uint id, int x, int y, int HP) : id(id), coordinate(x, y), HP(HP) {}

Player::~Player() {}

uint Player::getID() const {
	return id;
}
const Coordinate& Player::getCoord() const {
	return coordinate;
}

int Player::getHP() const {
	return HP;
}

std::string Player::getBoardID() const {
	return ((id < 10) ? ("0" + std::to_string(id)) : (std::to_string(id)));
}

bool Player::isDead() const {
	return ((HP <= 0) ? (true) : (false));
}

void Player::executeMove(Move move) {
	if (move == NOOP || move == ATTACK)
		return ;
	coordinate = coordinate + move;
	std::cout << (getFullName())
			  << "(" << HP << ") moved "
			  << ((move == UP) ? ("UP") :
			  	 ((move == DOWN) ? ("DOWN") :
			  	 ((move == LEFT) ? ("LEFT") : ("RIGHT"))))
			  << "." << std::endl;
	return ;
}

bool Player::attackTo(Player *player) {
	if (this == player)
		return false;
	int rhsHP = player -> HP;
	player -> HP -= std::max((Entity::damageForWeapon(getWeapon()) - Entity::damageReductionForArmor(player -> getArmor())), 0);
	std::cout << (getFullName())
			  << "(" << HP << ") ATTACKED "
			  << (player -> getFullName())
			  << "(" << (rhsHP) << ")! (-"
			  << (rhsHP - (player -> HP))
			  << ")" << std::endl;
	return ((player -> isDead()) ? (true) : (false));
}

void Player::damage(int d) {
	HP -= d;
}

